#!/usr/bin/env python2
# -*- coding: utf-8 -*-
# Author: Brian Tomlinson
# Contact: darthlukan@gmail.com
# Description: Simple update notifier for Liquid Lemur Linux,
# meant to be run via ~/.config/autostart/lupdater.desktop but
# can also be run from the applications menu.
# License: GPLv2

import time
import subprocess

# Timer variable. Changing this number will adjust the sleeper.
# The value is in seconds, the default is 4 hours.
# TODO: Settings like these should really be read from ~/.config/foo.py.
rest = 14400

# Create the log
open('/tmp/lupdater.log', 'w+')

# We want to append the existing log, not overwrite lines.
# TODO: we should really clear the log once it reaches a certain size for disk
# space issues on systems that don't get rebooted often.
f = open('/tmp/lupdater.log', 'a+')

class Sleeper():
    '''Provides a method to force sleeping.'''

    def slp_time(self):
        '''Sleeps based on the value of the global rest variable.  The value is
        in seconds and set to 4 hours by default.'''
        while True:
            f.write(time.ctime() + ': lupdater going to sleep.')
            time.sleep(rest)
            f.write(time.ctime() + ': lupdater woke up.')
            run_me()


class Pacman():
    '''Provides functions to call pacman and update the repos, as well as
    return a list with number of updates. '''

    def pac_update(self):

        subprocess.call(['/usr/bin/notify-send', 'Updating repositories for update check...'], shell=False)

        upd = subprocess.Popen('sudo pacman -Syy', shell=True, stdout=subprocess.PIPE)
        stdout, stderr = upd.communicate()

    def pac_list(self):

        subprocess.call(['/usr/bin/notify-send', 'Checking for updates...'], shell=False)

        paclist = []

        lst = subprocess.Popen('pacman -Qu', shell=True, stdout=subprocess.PIPE)

        for line in lst.stdout:
            line.rstrip('\r\n')
            paclist.append(line)

        numupdates = len(paclist)

        if numupdates >= 1:
            subprocess.call(['/usr/bin/notify-send', '%s %s %s' % ('You have', numupdates, 'updates available!')], shell=False)
            f.write(time.ctime() + ': lupdater had updates available.\n')
            f.flush()

        else:
            subprocess.call(['/usr/bin/notify-send', 'Your system is already up to date! :)'], shell=False)
            f.write(time.ctime() + ': System is up to date.\n')
            f.flush()
        # "Future-proofing"
        return numupdates, paclist

def run_sleepless(x):
    # This is an ugly hack run by the GUI to avoid putting its process to sleep.
    # TODO: Find a better way that doesn't involve multi-threading.
    f.write(time.ctime() + ': lupdater running...\n')
    f.flush()

    p = Pacman()
    p.pac_update()
    p.pac_list()

def run_me():

    # Write to the log, f.flush() helps when using tail on lupdater.log.
    f.write(time.ctime() + ': lupdater running...\n')
    f.flush()
    # Meat and Potatoes
    p = Pacman()
    p.pac_update()
    p.pac_list()
    # Go to sleep
    s = Sleeper()
    s.slp_time()

if __name__ == '__main__':
    run_me()